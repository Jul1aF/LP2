﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade8
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string aux = "";
            string[] nomes = new string[10];
            int[] caracteres = new int[10];

            for (int i = 0; i < 10; i++) {
                aux = Interaction.InputBox("Digite o nome das pessoas", "Entrada de nome");
                if(aux.Replace(" ", "").Length == 0)
                {
                    MessageBox.Show("Digite um nome válido");
                    i--;
                } 
                else
                {
                    caracteres[i] = aux.Replace(" ", "").Length;
                    nomes[i] = aux;
                }
            }

            for (int i = 0; i < 10; i++) { 
                lstbxNomes.Items.Add("O nome "+ nomes[i] + " tem " + caracteres[i] + " caracteres.");
            }
        }
    }
}

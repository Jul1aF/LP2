﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Microsoft.VisualBasic;

namespace Atividade8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";

            for (int i = 0; i < 20; i++) {
                aux = Interaction.InputBox("Digite o número", "Entrada de dados");
                if(aux == "")
                {
                    break;
                }
                if(!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
            }
            Array.Reverse(vetor);
            aux = "";

            foreach (int x in vetor) {
                aux += x+"\n";
            }
            MessageBox.Show(aux);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string aux = "";
            double media = 0;
            string saida = "";

            for (int i = 0; i < 20; i++) {
                media = 0;
                for (int j = 0; j < 3; j++) {
                    aux = Interaction.InputBox($"Digite a {j + 1}ª nota do aluno {i + 1}", "Entrada de notas");
                    if(!double.TryParse(aux, out notas[i, j]) || notas[i,j] < 0 || notas[i,j] > 10)
                    {
                        MessageBox.Show("Digite uma nota válida");
                        j--;
                    } 
                    else
                    {
                        media += notas[i, j];
                    }
                    media = media / 3;
                    saida += "Aluno " + i + 1 + ": Média:" + media.ToString("N2") + "\n";
                }
                MessageBox.Show(saida);

            }

        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frmExercicio4 obj = new frmExercicio4();
            obj.Show();
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList();
            alunos.Add("Ana");
            alunos.Add("André");
            alunos.Add("Beatriz");
            alunos.Add("Camila");
            alunos.Add("João");
            alunos.Add("Joana");
            alunos.Add("Otávio");
            alunos.Add("Marcelo");
            alunos.Add("Pedro");
            alunos.Add("Thais");

            string aux = "";

            foreach (string nome in alunos)
            {
                aux += nome + "\n";
            }
            MessageBox.Show("Arraylist antes:\n"+aux);

            alunos.Remove("Otávio");

            aux = "";

            foreach (string nome in alunos)
            {
                aux += nome + "\n";
            }
            MessageBox.Show("Arraylist depois: " + aux);

        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frmExercicio5 obj = new frmExercicio5();
            obj.Show();
        }
    
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Microsoft.VisualBasic;

namespace Atividade8
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int[,] vetor = new int[8, 10];
            string[,] resposta = new string[8, 10];
            string[] gabarito = new string[10] {"A", "B", "C", "E", "B", "A", "D", "D", "B", "A"};
            string aux = "";

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    aux = Interaction.InputBox($"Digite a resposta da questão {j + 1} do aluno {i + 1}", "Entrada de Dados");

                    if (aux == "")
                    {
                        break;
                    }
                    else if (aux != "A" && aux != "B" && aux != "C" && aux != "D" && aux != "E")
                    {
                        MessageBox.Show("Resposta inválida");
                        j--;
                    }
                    else
                    {
                        resposta[i, j] = aux;
                        if (aux == gabarito[j])
                        {
                            lstbxGabarito.Items.Add($"aluno {i + 1} acertou questão {j + 1}. Era {gabarito[j]} escolheu {aux}");
                        }
                        else
                        {
                            lstbxGabarito.Items.Add($"aluno {i + 1} errou questão {j + 1}. era {gabarito[j]} escolheu {aux}");
                        }
                        
                    }
                }

            }
        }
    }
}

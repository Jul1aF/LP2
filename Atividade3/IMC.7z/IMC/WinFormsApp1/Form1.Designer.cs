﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPesoAtual = new Label();
            lblAltura = new Label();
            lblIMC = new Label();
            txtImc = new TextBox();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            txtPeso = new TextBox();
            txtAltura = new TextBox();
            SuspendLayout();
            // 
            // lblPesoAtual
            // 
            lblPesoAtual.AutoSize = true;
            lblPesoAtual.Location = new Point(129, 49);
            lblPesoAtual.Name = "lblPesoAtual";
            lblPesoAtual.Size = new Size(61, 15);
            lblPesoAtual.TabIndex = 0;
            lblPesoAtual.Text = "Peso atual";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Location = new Point(151, 95);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(39, 15);
            lblAltura.TabIndex = 1;
            lblAltura.Text = "Altura";
            // 
            // lblIMC
            // 
            lblIMC.AutoSize = true;
            lblIMC.Location = new Point(151, 176);
            lblIMC.Name = "lblIMC";
            lblIMC.Size = new Size(29, 15);
            lblIMC.TabIndex = 2;
            lblIMC.Text = "IMC";
            // 
            // txtImc
            // 
            txtImc.Enabled = false;
            txtImc.Location = new Point(224, 173);
            txtImc.Name = "txtImc";
            txtImc.Size = new Size(205, 23);
            txtImc.TabIndex = 5;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(36, 247);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(106, 42);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(192, 247);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(106, 42);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(353, 247);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(106, 42);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // txtPeso
            // 
            txtPeso.Location = new Point(224, 41);
            txtPeso.Name = "txtPeso";
            txtPeso.Size = new Size(100, 23);
            txtPeso.TabIndex = 9;
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(224, 87);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(100, 23);
            txtAltura.TabIndex = 10;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(485, 330);
            Controls.Add(txtAltura);
            Controls.Add(txtPeso);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(txtImc);
            Controls.Add(lblIMC);
            Controls.Add(lblAltura);
            Controls.Add(lblPesoAtual);
            Name = "Form1";
            Text = "Calculadora IMC";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPesoAtual;
        private Label lblAltura;
        private Label lblIMC;
        private TextBox txtImc;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnSair;
        private TextBox txtPeso;
        private TextBox txtAltura;
    }
}

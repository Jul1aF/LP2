namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        double altura, peso, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtImc.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtPeso.Text, out peso) ||  peso<=0 )
            {
                MessageBox.Show("Peso inv�lido");
                txtPeso.Focus();
                txtPeso.Clear();

                if(!Double.TryParse(txtAltura.Text, out altura) || altura <=0)
                {
                    MessageBox.Show("Altura inv�lida");
                    txtAltura.Focus();
                    txtAltura.Clear();
                }
            } else 
            {
                if (!Double.TryParse(txtAltura.Text, out altura) || altura <= 0)
                {
                    MessageBox.Show("Altura inv�lida");
                    txtAltura.Focus();
                    txtAltura.Clear();
                } else
                {
                    imc = peso / (altura * altura);
                    
                    if (imc < 18.5)
                    {
                        txtImc.Text = imc.ToString("F")+" - Magreza";
                    } else if (imc<25){
                        txtImc.Text = imc.ToString("F")+" - Normal";
                    } else if (imc<30)
                    {
                        txtImc.Text = imc.ToString("F")+" - Sobrepeso";
                    } else if (imc<40){
                        txtImc.Text = imc.ToString("F")+" - Obesidade";
                    } else
                    {
                        txtImc.Text = imc.ToString("F")+" - Obesidade grave";
                    }
                }
            }
            
            
        }
    }
}

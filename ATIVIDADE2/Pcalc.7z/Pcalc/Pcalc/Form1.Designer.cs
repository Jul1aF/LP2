﻿namespace Pcalc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNumero1 = new Label();
            lblNumero2 = new Label();
            btnMais = new Button();
            lblResultado = new Label();
            txtNumero1 = new TextBox();
            txtNumero2 = new TextBox();
            txtResultado = new TextBox();
            btnMenos = new Button();
            btnMultiplicacao = new Button();
            btnDivisao = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            SuspendLayout();
            // 
            // lblNumero1
            // 
            lblNumero1.AutoSize = true;
            lblNumero1.Location = new Point(82, 119);
            lblNumero1.Name = "lblNumero1";
            lblNumero1.Size = new Size(92, 25);
            lblNumero1.TabIndex = 0;
            lblNumero1.Text = "Numero 1";
            // 
            // lblNumero2
            // 
            lblNumero2.AutoSize = true;
            lblNumero2.Location = new Point(82, 216);
            lblNumero2.Name = "lblNumero2";
            lblNumero2.Size = new Size(92, 25);
            lblNumero2.TabIndex = 1;
            lblNumero2.Text = "Numero 2";
            // 
            // btnMais
            // 
            btnMais.Location = new Point(62, 448);
            btnMais.Name = "btnMais";
            btnMais.Size = new Size(173, 66);
            btnMais.TabIndex = 2;
            btnMais.Text = "+";
            btnMais.UseVisualStyleBackColor = true;
            btnMais.Click += btnMais_Click;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(82, 345);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(90, 25);
            lblResultado.TabIndex = 8;
            lblResultado.Text = "Resultado";
            // 
            // txtNumero1
            // 
            txtNumero1.Location = new Point(212, 119);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(412, 31);
            txtNumero1.TabIndex = 9;
            txtNumero1.Validated += txtNumero1_Validated;
            // 
            // txtNumero2
            // 
            txtNumero2.Location = new Point(212, 210);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(412, 31);
            txtNumero2.TabIndex = 10;
            txtNumero2.Validated += txtNumero2_Validated;
            // 
            // txtResultado
            // 
            txtResultado.BackColor = SystemColors.GradientInactiveCaption;
            txtResultado.Enabled = false;
            txtResultado.ForeColor = SystemColors.Desktop;
            txtResultado.Location = new Point(212, 339);
            txtResultado.Name = "txtResultado";
            txtResultado.Size = new Size(412, 31);
            txtResultado.TabIndex = 11;
            // 
            // btnMenos
            // 
            btnMenos.Location = new Point(266, 448);
            btnMenos.Name = "btnMenos";
            btnMenos.Size = new Size(173, 66);
            btnMenos.TabIndex = 12;
            btnMenos.Text = "-";
            btnMenos.UseVisualStyleBackColor = true;
            btnMenos.Click += btnMenos_Click;
            // 
            // btnMultiplicacao
            // 
            btnMultiplicacao.Location = new Point(473, 448);
            btnMultiplicacao.Name = "btnMultiplicacao";
            btnMultiplicacao.Size = new Size(173, 66);
            btnMultiplicacao.TabIndex = 13;
            btnMultiplicacao.Text = "*";
            btnMultiplicacao.UseVisualStyleBackColor = true;
            btnMultiplicacao.Click += btnMultiplicacao_Click;
            // 
            // btnDivisao
            // 
            btnDivisao.Location = new Point(682, 448);
            btnDivisao.Name = "btnDivisao";
            btnDivisao.Size = new Size(173, 66);
            btnDivisao.TabIndex = 14;
            btnDivisao.Text = "/";
            btnDivisao.UseVisualStyleBackColor = true;
            btnDivisao.Click += btnDivisao_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(698, 144);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(173, 66);
            btnLimpar.TabIndex = 15;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(698, 275);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(173, 66);
            btnSair.TabIndex = 16;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1007, 583);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnDivisao);
            Controls.Add(btnMultiplicacao);
            Controls.Add(btnMenos);
            Controls.Add(txtResultado);
            Controls.Add(txtNumero2);
            Controls.Add(txtNumero1);
            Controls.Add(lblResultado);
            Controls.Add(btnMais);
            Controls.Add(lblNumero2);
            Controls.Add(lblNumero1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNumero1;
        private Label lblNumero2;
        private Button btnMais;
        private Label lblResultado;
        private TextBox txtNumero1;
        private TextBox txtNumero2;
        private TextBox txtResultado;
        private Button btnMenos;
        private Button btnMultiplicacao;
        private Button btnDivisao;
        private Button btnLimpar;
        private Button btnSair;
    }
}

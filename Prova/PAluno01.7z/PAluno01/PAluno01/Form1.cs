﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxNotas.Items.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[5, 3];
            double[] mediaAluno = new double[5];
            double mediaGeral = 0;
            string aux = "";
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox($"Digite a nota do aluno {i + 1} do professor {j + 1}", "Entrada de Notas");
                    if (aux == "")
                    {
                        Close();
                    }
                    else if (!double.TryParse(aux, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Digite uma nota válida");
                        j--;
                    }
                    else
                    {
                        
                        mediaGeral += notas[i, j];
                        mediaAluno[i] += notas[i, j];                          
                
                    }


                }
            }

            for (int i = 0; i < 5; i++) {
                int j = 0;
                lstbxNotas.Items.Add($"Aluno:{i + 1}  Nota Professor {j + 1}  {notas[i, j]:F2} / Nota Professor {j + 2}  {notas[i, j+1]:F2} / Nota Professor {j + 3}  {notas[i, j+2]:F2} / Média  {mediaAluno[i]/3:F2}");
            }
            lstbxNotas.Items.Add($"Média Geral de Alunos: {mediaGeral / 15:F2}");
        }
    }
}

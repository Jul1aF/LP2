﻿namespace PFerramenta0030482423033
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSobre));
            this.ptbImagem = new System.Windows.Forms.PictureBox();
            this.lblDireito = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblDescricao = new System.Windows.Forms.Label();
            this.lblContato = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ptbImagem)).BeginInit();
            this.SuspendLayout();
            // 
            // ptbImagem
            // 
            this.ptbImagem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ptbImagem.Image = ((System.Drawing.Image)(resources.GetObject("ptbImagem.Image")));
            this.ptbImagem.InitialImage = null;
            this.ptbImagem.Location = new System.Drawing.Point(311, 12);
            this.ptbImagem.Name = "ptbImagem";
            this.ptbImagem.Size = new System.Drawing.Size(443, 319);
            this.ptbImagem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptbImagem.TabIndex = 0;
            this.ptbImagem.TabStop = false;
            // 
            // lblDireito
            // 
            this.lblDireito.AutoSize = true;
            this.lblDireito.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDireito.Location = new System.Drawing.Point(335, 334);
            this.lblDireito.Name = "lblDireito";
            this.lblDireito.Size = new System.Drawing.Size(405, 16);
            this.lblDireito.TabIndex = 1;
            this.lblDireito.Text = "Todos os direitos reservados  Natanael Freitas™  e Júlia Ferreira™.\r\n";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(98, 12);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(96, 16);
            this.lblTitulo.TabIndex = 2;
            this.lblTitulo.Text = "PFerramenta";
            // 
            // lblDescricao
            // 
            this.lblDescricao.AutoSize = true;
            this.lblDescricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescricao.Location = new System.Drawing.Point(2, 28);
            this.lblDescricao.Name = "lblDescricao";
            this.lblDescricao.Size = new System.Drawing.Size(303, 144);
            this.lblDescricao.TabIndex = 3;
            this.lblDescricao.Text = resources.GetString("lblDescricao.Text");
            this.lblDescricao.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblContato
            // 
            this.lblContato.AutoSize = true;
            this.lblContato.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContato.Location = new System.Drawing.Point(54, 187);
            this.lblContato.Name = "lblContato";
            this.lblContato.Size = new System.Drawing.Size(203, 144);
            this.lblContato.TabIndex = 4;
            this.lblContato.Text = "Contato\r\nNatanael Freitas\r\nnfreitas738@gmail.com\r\nlinkedin/in/natan-freitas/\r\n\r\nJ" +
    "úlia Ferreira\r\nliaferreira.2302@gmail.com\r\nlinkedin.com/in/julia-ferreira-s/";
            this.lblContato.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(766, 414);
            this.Controls.Add(this.lblContato);
            this.Controls.Add(this.lblDescricao);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lblDireito);
            this.Controls.Add(this.ptbImagem);
            this.Name = "frmSobre";
            this.Text = "frmSobre";
            ((System.ComponentModel.ISupportInitialize)(this.ptbImagem)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox ptbImagem;
        private System.Windows.Forms.Label lblDireito;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblDescricao;
        private System.Windows.Forms.Label lblContato;
    }
}
﻿namespace Ptriangulo
{
    partial class Atividade4
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Atividade4));
            lblValorA = new Label();
            lblValorB = new Label();
            lblValorC = new Label();
            txtValorA = new TextBox();
            txtValorB = new TextBox();
            txtValorC = new TextBox();
            pictureBox1 = new PictureBox();
            btnExecutar = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblValorA
            // 
            lblValorA.AutoSize = true;
            lblValorA.Location = new Point(53, 79);
            lblValorA.Name = "lblValorA";
            lblValorA.Size = new Size(60, 15);
            lblValorA.TabIndex = 0;
            lblValorA.Text = "Valor de A";
            // 
            // lblValorB
            // 
            lblValorB.AutoSize = true;
            lblValorB.Location = new Point(53, 151);
            lblValorB.Name = "lblValorB";
            lblValorB.Size = new Size(59, 15);
            lblValorB.TabIndex = 1;
            lblValorB.Text = "Valor de B";
            // 
            // lblValorC
            // 
            lblValorC.AutoSize = true;
            lblValorC.Location = new Point(53, 229);
            lblValorC.Name = "lblValorC";
            lblValorC.Size = new Size(60, 15);
            lblValorC.TabIndex = 2;
            lblValorC.Text = "Valor de C";
            // 
            // txtValorA
            // 
            txtValorA.Location = new Point(143, 71);
            txtValorA.Name = "txtValorA";
            txtValorA.Size = new Size(185, 23);
            txtValorA.TabIndex = 3;
            // 
            // txtValorB
            // 
            txtValorB.Location = new Point(143, 148);
            txtValorB.Name = "txtValorB";
            txtValorB.Size = new Size(185, 23);
            txtValorB.TabIndex = 4;
            // 
            // txtValorC
            // 
            txtValorC.Location = new Point(143, 226);
            txtValorC.Name = "txtValorC";
            txtValorC.Size = new Size(185, 23);
            txtValorC.TabIndex = 5;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.Location = new Point(405, 71);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(381, 304);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // btnExecutar
            // 
            btnExecutar.Location = new Point(109, 340);
            btnExecutar.Name = "btnExecutar";
            btnExecutar.Size = new Size(156, 59);
            btnExecutar.TabIndex = 7;
            btnExecutar.Text = "Executar";
            btnExecutar.UseVisualStyleBackColor = true;
            btnExecutar.Click += btnExecutar_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(314, 340);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(156, 59);
            btnLimpar.TabIndex = 8;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(523, 340);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(156, 59);
            btnSair.TabIndex = 9;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // Atividade4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(760, 450);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnExecutar);
            Controls.Add(pictureBox1);
            Controls.Add(txtValorC);
            Controls.Add(txtValorB);
            Controls.Add(txtValorA);
            Controls.Add(lblValorC);
            Controls.Add(lblValorB);
            Controls.Add(lblValorA);
            Name = "Atividade4";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblValorA;
        private Label lblValorB;
        private Label lblValorC;
        private TextBox txtValorA;
        private TextBox txtValorB;
        private TextBox txtValorC;
        private PictureBox pictureBox1;
        private Button btnExecutar;
        private Button btnLimpar;
        private Button btnSair;
    }
}

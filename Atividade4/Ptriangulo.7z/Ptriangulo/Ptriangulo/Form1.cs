using System.Diagnostics.Eventing.Reader;

namespace Ptriangulo
{
    public partial class Atividade4 : Form
    {
        double valorA, valorB, valorC, modBC, modAC, modAB;
        public Atividade4()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValorA.Text, out valorA) || valorA <= 0)
            {
                MessageBox.Show("Valor de A inv�lido.");
                txtValorA.Clear();

                if (!Double.TryParse(txtValorB.Text, out valorB) || valorB <= 0)
                {
                    MessageBox.Show("Valor de B inv�lido.");
                    txtValorB.Clear();
                }

                if (!Double.TryParse(txtValorC.Text, out valorC) || valorC <= 0)
                {
                    MessageBox.Show("Valor de C inv�lido.");
                    txtValorC.Clear();
                }

            }
            else if (!Double.TryParse(txtValorB.Text, out valorB) || valorB <= 0)
            {
                MessageBox.Show("Valor de B inv�lido.");
                txtValorB.Clear();

                if (!Double.TryParse(txtValorC.Text, out valorC) || valorC <= 0)
                {
                    MessageBox.Show("Valor de C inv�lido.");
                    txtValorC.Clear();
                }
            }
            else if (!Double.TryParse(txtValorC.Text, out valorC) || valorC <= 0)
            {
                MessageBox.Show("Valor de C inv�lido.");
                txtValorC.Clear();
            }
            else
            {
                txtValorA.Text = valorA.ToString();
                txtValorB.Text = valorB.ToString();
                txtValorC.Text = valorC.ToString();



                if (valorB - valorC < 0)
                {
                    modBC = (valorB - valorC) * -1;

                }
                else
                {
                    modBC = valorB - valorC;
                }
                if (valorA - valorC < 0) {
                    modAC = (valorA - valorC) * -1;
                } else
                {
                    modAC = valorA - valorC;
                }
                if (valorA - valorB < 0)
                {
                    modAB = (valorA - valorB) * -1;
                } else
                {
                    modAB = valorA - valorB;
                }

                if(modBC < valorA && valorA < valorB+valorC)
                {
                        if (valorA == valorB && valorB == valorC)
                        {
                            MessageBox.Show("� um tri�ngulo equil�tero");
                        }
                        else if (valorA == valorB || valorB == valorC || valorA == valorC)
                        {
                            MessageBox.Show("� um tri�ngulo Is�celes");
                        }
                        else
                        {
                            MessageBox.Show("� um tri�ngulo escaleno");
                        }
                } else if(modAC < valorB && valorB < valorA + valorC)
                {
                    if (valorA == valorB && valorB == valorC)
                    {
                        MessageBox.Show("� um tri�ngulo equil�tero");
                    }
                    else if (valorA == valorB || valorB == valorC || valorA == valorC)
                    {
                        MessageBox.Show("� um tri�ngulo Is�celes");
                    }
                    else
                    {
                        MessageBox.Show("� um tri�ngulo escaleno");
                    }
                }
                else if (modAB < valorC && valorC < valorA + valorB)
                {
                    if (valorA == valorB && valorB == valorC)
                    {
                        MessageBox.Show("� um tri�ngulo equil�tero");
                    }
                    else if (valorA == valorB || valorB == valorC || valorA == valorC)
                    {
                        MessageBox.Show("� um tri�ngulo Is�celes");
                    }
                    else
                    {
                        MessageBox.Show("� um tri�ngulo escaleno");
                    }
                }
                else
                {
                    MessageBox.Show("N�o � um tri�ngulo");

                }
            }   
        }
    }
}

﻿namespace PTesteMetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPalavra1 = new Label();
            lblPalavra2 = new Label();
            txtPalavra1 = new TextBox();
            txtPalavra2 = new TextBox();
            btnTestar = new Button();
            btnInserir = new Button();
            btnAsterisco = new Button();
            SuspendLayout();
            // 
            // lblPalavra1
            // 
            lblPalavra1.AutoSize = true;
            lblPalavra1.Location = new Point(53, 50);
            lblPalavra1.Margin = new Padding(2, 0, 2, 0);
            lblPalavra1.Name = "lblPalavra1";
            lblPalavra1.Size = new Size(54, 15);
            lblPalavra1.TabIndex = 0;
            lblPalavra1.Text = "Palavra 1";
            // 
            // lblPalavra2
            // 
            lblPalavra2.AutoSize = true;
            lblPalavra2.Location = new Point(53, 103);
            lblPalavra2.Margin = new Padding(2, 0, 2, 0);
            lblPalavra2.Name = "lblPalavra2";
            lblPalavra2.Size = new Size(54, 15);
            lblPalavra2.TabIndex = 1;
            lblPalavra2.Text = "Palavra 2";
            // 
            // txtPalavra1
            // 
            txtPalavra1.Location = new Point(130, 50);
            txtPalavra1.Margin = new Padding(2);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(199, 23);
            txtPalavra1.TabIndex = 2;
            // 
            // txtPalavra2
            // 
            txtPalavra2.Location = new Point(130, 101);
            txtPalavra2.Margin = new Padding(2);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(199, 23);
            txtPalavra2.TabIndex = 3;
            // 
            // btnTestar
            // 
            btnTestar.Location = new Point(26, 168);
            btnTestar.Margin = new Padding(2);
            btnTestar.Name = "btnTestar";
            btnTestar.Size = new Size(139, 49);
            btnTestar.TabIndex = 4;
            btnTestar.Text = "Testar iguais";
            btnTestar.UseVisualStyleBackColor = true;
            btnTestar.Click += btnTestar_Click;
            // 
            // btnInserir
            // 
            btnInserir.Location = new Point(206, 168);
            btnInserir.Margin = new Padding(2);
            btnInserir.Name = "btnInserir";
            btnInserir.Size = new Size(139, 49);
            btnInserir.TabIndex = 5;
            btnInserir.Text = "Inserir texto 1 no 2";
            btnInserir.UseVisualStyleBackColor = true;
            btnInserir.Click += btnInserir_Click;
            // 
            // btnAsterisco
            // 
            btnAsterisco.Location = new Point(385, 168);
            btnAsterisco.Margin = new Padding(2);
            btnAsterisco.Name = "btnAsterisco";
            btnAsterisco.Size = new Size(139, 49);
            btnAsterisco.TabIndex = 6;
            btnAsterisco.Text = "Inserir asteriscos no texto 1";
            btnAsterisco.UseVisualStyleBackColor = true;
            btnAsterisco.Click += btnAsterisco_Click;
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(560, 270);
            Controls.Add(btnAsterisco);
            Controls.Add(btnInserir);
            Controls.Add(btnTestar);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Controls.Add(lblPalavra2);
            Controls.Add(lblPalavra1);
            Margin = new Padding(2);
            Name = "frmExercicio2";
            Text = "frmExercicio2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPalavra1;
        private Label lblPalavra2;
        private TextBox txtPalavra1;
        private TextBox txtPalavra2;
        private Button btnTestar;
        private Button btnInserir;
        private Button btnAsterisco;
    }
}
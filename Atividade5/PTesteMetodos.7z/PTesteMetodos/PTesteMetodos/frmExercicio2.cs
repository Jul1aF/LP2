﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            if (txtPalavra1.Text == "")
            {
                MessageBox.Show("Palavra 1 em branco.");
                txtPalavra1.Focus();
            }
            else if (txtPalavra2.Text == "")
            {
                MessageBox.Show("Palavra 2 em branco.");
                txtPalavra2.Focus();
            }
            else
            {
                if (String.Compare(txtPalavra1.Text, txtPalavra2.Text) == 0)
                {
                    MessageBox.Show("São iguais.");
                    txtPalavra1.Clear();
                    txtPalavra2.Clear();
                }
                else
                {
                    MessageBox.Show("São diferentes.");
                    txtPalavra1.Clear();
                    txtPalavra2.Clear();
                }
            }
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            int tamanho;
            string metade = txtPalavra2.Text;
            if (txtPalavra1.Text == "")
            {
                MessageBox.Show("Palavra 1 em branco.");
                txtPalavra1.Focus();
            }
            else if (txtPalavra2.Text == "")
            {
                MessageBox.Show("Palavra 2 em branco");
                txtPalavra2.Focus();
            }
            else
            {
                tamanho = (txtPalavra2.TextLength) / 2;

                metade = metade.Substring(0, tamanho);
                txtPalavra2.Text = metade + txtPalavra1.Text;
                txtPalavra1.Clear();

            }
        }

        private void btnAsterisco_Click(object sender, EventArgs e)
        {
            int tamanho; 
            if (txtPalavra1.Text == "")
            {
                MessageBox.Show("Palavra 1 em branco.");
                txtPalavra1.Focus();
            } else
            {
                tamanho = (txtPalavra1.TextLength) / 2;

                txtPalavra2.Text = txtPalavra1.Text.Insert(tamanho, "**");
            }
        }
    }
}

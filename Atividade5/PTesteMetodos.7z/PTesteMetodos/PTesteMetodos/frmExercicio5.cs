﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int numero1 = 0, numero2 = 0;
             
            if (!int.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("Insira um número 1 válido.");
                txtNumero1.Clear();

                if(!int.TryParse(txtNumero2.Text, out numero2))
                {
                    MessageBox.Show("Insira um número 2 válido.");
                    txtNumero2.Clear();
                }

            } else if(!int.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("Insira um número 2 válido.");
                txtNumero2.Clear();
            }     
            else if (numero1 >= numero2)
            {
                MessageBox.Show("O número 1 não pode ser maior ou igual que o número 2.");
                txtNumero1.Clear();
                txtNumero2.Clear();
            } else
            {
                Random sorteio = new Random();
                int aleatorio = sorteio.Next(numero1, numero2);
                MessageBox.Show(aleatorio.ToString());
            }
        }
    }
}

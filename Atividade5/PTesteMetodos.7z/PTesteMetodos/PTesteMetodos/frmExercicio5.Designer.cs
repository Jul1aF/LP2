﻿namespace PTesteMetodos
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSortear = new Button();
            txtNumero2 = new TextBox();
            txtNumero1 = new TextBox();
            lblNumero2 = new Label();
            lblNumero1 = new Label();
            SuspendLayout();
            // 
            // btnSortear
            // 
            btnSortear.Location = new Point(217, 210);
            btnSortear.Margin = new Padding(2);
            btnSortear.Name = "btnSortear";
            btnSortear.Size = new Size(139, 49);
            btnSortear.TabIndex = 17;
            btnSortear.Text = "Sortear";
            btnSortear.UseVisualStyleBackColor = true;
            btnSortear.Click += btnSortear_Click;
            // 
            // txtNumero2
            // 
            txtNumero2.Location = new Point(188, 148);
            txtNumero2.Margin = new Padding(2);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(199, 23);
            txtNumero2.TabIndex = 16;
            // 
            // txtNumero1
            // 
            txtNumero1.Location = new Point(188, 97);
            txtNumero1.Margin = new Padding(2);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(199, 23);
            txtNumero1.TabIndex = 15;
            // 
            // lblNumero2
            // 
            lblNumero2.AutoSize = true;
            lblNumero2.Location = new Point(76, 148);
            lblNumero2.Margin = new Padding(2, 0, 2, 0);
            lblNumero2.Name = "lblNumero2";
            lblNumero2.Size = new Size(60, 15);
            lblNumero2.TabIndex = 14;
            lblNumero2.Text = "Numero 2";
            // 
            // lblNumero1
            // 
            lblNumero1.AutoSize = true;
            lblNumero1.Location = new Point(76, 98);
            lblNumero1.Margin = new Padding(2, 0, 2, 0);
            lblNumero1.Name = "lblNumero1";
            lblNumero1.Size = new Size(60, 15);
            lblNumero1.TabIndex = 13;
            lblNumero1.Text = "Numero 1";
            // 
            // frmExercicio5
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(608, 373);
            Controls.Add(btnSortear);
            Controls.Add(txtNumero2);
            Controls.Add(txtNumero1);
            Controls.Add(lblNumero2);
            Controls.Add(lblNumero1);
            Name = "frmExercicio5";
            Text = "frmExercicio5";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSortear;
        private TextBox txtNumero2;
        private TextBox txtNumero1;
        private Label lblNumero2;
        private Label lblNumero1;
    }
}
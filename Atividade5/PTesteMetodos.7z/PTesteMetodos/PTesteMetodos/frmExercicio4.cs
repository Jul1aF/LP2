﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumero_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contnum = 0;

            while (contador < rchtxtFrase.Text.Length)
            {
                if (Char.IsNumber(rchtxtFrase.Text[contador]))
                {
                    contnum++;
                }
                contador++;
            }
            if(contnum == 1)
            {
                MessageBox.Show("Tem "+contnum+" número.");
            } else if (contador > 1)
            {
                MessageBox.Show("Tem "+contnum+" números.");
            }
            else
            {
                MessageBox.Show("Não tem número.");
            }

        }

        private void bntBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i+1;
                    break;
                }
                
            }
            if (posicao > 0)
            {
                MessageBox.Show("A posição é " + posicao);
            }
            else
            {
                MessageBox.Show("Não há espaços em branco.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int contador=0;
            foreach (var c in rchtxtFrase.Text)
            {
                if(Char.IsLetter(c))
                {
                    contador++;
                }
            }

            if (contador > 1) {
                MessageBox.Show("Há "+contador+" caracteres alfabéticos.");
            } else if (contador == 1)
            {
                MessageBox.Show("Há "+contador+" caractere alfabético.");
            } else
            {
                MessageBox.Show("Não há caracteres alfabéticos.");
            }
        }
    }
}

﻿namespace PTesteMetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnInserir = new Button();
            btnTestar = new Button();
            txtPalavra2 = new TextBox();
            txtPalavra1 = new TextBox();
            lblPalavra2 = new Label();
            lblPalavra1 = new Label();
            SuspendLayout();
            // 
            // btnInserir
            // 
            btnInserir.Location = new Point(451, 292);
            btnInserir.Name = "btnInserir";
            btnInserir.Size = new Size(198, 81);
            btnInserir.TabIndex = 12;
            btnInserir.Text = "Reverter";
            btnInserir.UseVisualStyleBackColor = true;
            btnInserir.Click += btnInserir_Click;
            // 
            // btnTestar
            // 
            btnTestar.Location = new Point(120, 292);
            btnTestar.Name = "btnTestar";
            btnTestar.Size = new Size(198, 81);
            btnTestar.TabIndex = 11;
            btnTestar.Text = "Remover ocorrencia";
            btnTestar.UseVisualStyleBackColor = true;
            btnTestar.Click += btnTestar_Click;
            // 
            // txtPalavra2
            // 
            txtPalavra2.Location = new Point(323, 172);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(283, 31);
            txtPalavra2.TabIndex = 10;
            // 
            // txtPalavra1
            // 
            txtPalavra1.Location = new Point(323, 86);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(283, 31);
            txtPalavra1.TabIndex = 9;
            // 
            // lblPalavra2
            // 
            lblPalavra2.AutoSize = true;
            lblPalavra2.Location = new Point(163, 172);
            lblPalavra2.Name = "lblPalavra2";
            lblPalavra2.Size = new Size(82, 25);
            lblPalavra2.TabIndex = 8;
            lblPalavra2.Text = "Palavra 2";
            // 
            // lblPalavra1
            // 
            lblPalavra1.AutoSize = true;
            lblPalavra1.Location = new Point(163, 89);
            lblPalavra1.Name = "lblPalavra1";
            lblPalavra1.Size = new Size(82, 25);
            lblPalavra1.TabIndex = 7;
            lblPalavra1.Text = "Palavra 1";
            // 
            // frmExercicio3
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnInserir);
            Controls.Add(btnTestar);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Controls.Add(lblPalavra2);
            Controls.Add(lblPalavra1);
            Name = "frmExercicio3";
            Text = "frmExercicio3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnInserir;
        private Button btnTestar;
        private TextBox txtPalavra2;
        private TextBox txtPalavra1;
        private Label lblPalavra2;
        private Label lblPalavra1;
    }
}